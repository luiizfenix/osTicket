<?php

include dirname(__file__) . '/../../manage.php';
