
            <div class="clear"></div>
        </div> <!-- content -->
    </div> <!-- wizard -->
    <div id="footer" class="centered">Copyright &copy; 2013 <a target="_blank" href="http://osticket.com">osTicket.com</a></div>

    <script type="text/javascript" src="../js/jquery-1.11.2.min.js?901e5ea"></script>
    <script type="text/javascript" src="../js/jstz.min.js?901e5ea"></script>
    <script type="text/javascript" src="js/setup.js?901e5ea"></script>
    <script type="text/javascript" src="js/tips.js?901e5ea"></script>
</body>
</html>
